/* copyright(C) 2002 H.Kawai (under KL-01). */

int GO_abs(int n)
{
	if (n < 0)
		n = - n;
	return n;
}
